# Using the R Kernel

This folder contains notebooks:

*example_r_notebook.ipynb:* is an extremely brief demonstration of how to use R in the notebook once installed.
