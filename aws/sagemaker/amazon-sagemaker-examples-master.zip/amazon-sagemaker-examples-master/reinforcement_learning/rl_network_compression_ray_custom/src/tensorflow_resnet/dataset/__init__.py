from .base import Cifar10

__all__ = ['Cifar10']