These shared RL classes need to be moved into the sagemaker-containers package.

