class Capacity:
    min_weight = 100
    max_weight = 1000
    min_volume = 100
    max_volume = 1000
