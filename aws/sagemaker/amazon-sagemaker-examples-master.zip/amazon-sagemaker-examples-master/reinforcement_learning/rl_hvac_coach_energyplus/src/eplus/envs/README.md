# Notes

bcvtb folder has to be in this directory. It contains files that EnergyPlus references for external communications. pyEp.py assumes that bcvtb is in the same directory and sets the OS environment variable accordingly.
